#!/sps/hep/trend/software/PythonAppImages/GRANDpython
## =============================================================================
#$ -j n
#$ -notify
#$ -l ct=48:00:00
#$ -l vmem=3.0G
#$ -l fsize=1.0G
#$ -l sps=1
## =============================================================================
import os
import subprocess
import datetime
import tarfile
import glob
#Write the status:Running
now=datetime.datetime.now()
with open("Stshp_Iron_3.98_87.1_0.0_1.status",'a') as f:
  f.write(str(now)+" Running\n")
#RunAires
wd = os.getcwd()
cmd="/sps/hep/trend/software/Aires-19-04-00-ZHAireS-1.0.28/aires/bin/ZHAireSS23c<Stshp_Iron_3.98_87.1_0.0_1.inp>Stshp_Iron_3.98_87.1_0.0_1.stdout"
p = subprocess.Popen(cmd,cwd=wd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
stdout,stderr=p.communicate()
#Create HDF5 file
cmd="/sps/hep/trend/software/PythonAppImages/GRANDpython /sps/hep/trend/tueros/ZHAireS-Python/ZHAireSReader.py . standard"
p = subprocess.Popen(cmd,cwd=wd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
stdout,stderr=p.communicate()
#finally, we clean up, delete unneedded files, and compress critical files:
#we compress and save the .idf stores all the tables, and the sry can be regenerated from it if needed
tar = tarfile.open("Stshp_Iron_3.98_87.1_0.0_1.idf.tar.gz", "w:gz")
tar.add("Stshp_Iron_3.98_87.1_0.0_1.idf")
tar.close()
#we compress and save the .inp, .lgf, .py, .stdout (for future reference)
tar = tarfile.open("Stshp_Iron_3.98_87.1_0.0_1.reference.tar.gz", "w:gz")
tar.add("Stshp_Iron_3.98_87.1_0.0_1.inp")
tar.add("Stshp_Iron_3.98_87.1_0.0_1.lgf")
tar.add("Stshp_Iron_3.98_87.1_0.0_1.py")
tar.add("Stshp_Iron_3.98_87.1_0.0_1.stdout")
tar.close()
#we compress and save the original trace files (is not much space)
tar = tarfile.open("Stshp_Iron_3.98_87.1_0.0_1.traces.tar.gz", "w:gz")
for name in glob.glob("*.trace"):
  tar.add(name)
tar.add("antpos.dat")
tar.close()
#we delete the timefresnel-root.dat files.
for name in glob.glob("*timefresnel-root.dat"):
  os.remove(name)
#we delete the .idf, .inp, .lgf, .py, .stdout, already compressed
os.remove("Stshp_Iron_3.98_87.1_0.0_1.idf")
os.remove("Stshp_Iron_3.98_87.1_0.0_1.inp")
os.remove("Stshp_Iron_3.98_87.1_0.0_1.lgf")
os.remove("Stshp_Iron_3.98_87.1_0.0_1.stdout")
os.remove("Stshp_Iron_3.98_87.1_0.0_1.py")
#we delete the traces
for name in glob.glob("a*.trace"):
  os.remove(name)
os.remove("antpos.dat")
#Write the Status RunComplete
now=datetime.datetime.now()
with open("Stshp_Iron_3.98_87.1_0.0_1.status",'a') as f:
  f.write(str(now)+" RunComplete\n")
